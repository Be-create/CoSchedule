import AllRoutes from './component/AllRoutes';

import { Routes,Route } from "react-router-dom";
import { Homepage } from "./components/home";
import './App.css';
import Calendar from './components1/Calendar';

function App() {
  return (
    <div className="App">
       <AllRoutes />


    </div>
  );
}

export default App;

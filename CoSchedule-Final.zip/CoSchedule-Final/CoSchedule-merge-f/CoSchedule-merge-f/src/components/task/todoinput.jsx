




export const Todoinput = ()=>{
    return (
        <div>
            <input type="text" placeholder="Input task" />
        </div>
    )
}
